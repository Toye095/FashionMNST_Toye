#!/usr/bin/env python
# coding: utf-8

# In[34]:


import gradio as gr
import tensorflow as tf
import os
import numpy as np
from PIL import Image


# Dynamically get the path (works in both scripts and Jupyter)
current_dir = os.getcwd()
model_path = os.path.join(current_dir, "Fashion_MNST_Toye", "saved_model", "fashion_mnist_cnn.keras")

# Load the model
model = tf.keras.models.load_model(model_path)


# Define the labels for Fashion MNIST dataset
labels = [
    "T-shirt/top", "Trouser", "Pullover", "Dress", "Coat",
    "Sandal", "Shirt", "Sneaker", "Bag", "Ankle boot"
]

# Preprocessing function
def preprocess_image(image):
    image = image.resize((28, 28))  # Resize to 28x28
    image = image.convert("L")  # Convert to grayscale
    image = np.array(image) / 255.0  # Normalize pixel values
    image = np.expand_dims(image, axis=(0, -1))  # Add batch and channel dimensions
    return image

# Prediction function
def predict(image):
    image = preprocess_image(image)
    predictions = model.predict(image)
    class_idx = np.argmax(predictions, axis=1)[0]
    confidence = np.max(predictions)
    return f"Predicted: {labels[class_idx]} (Confidence: {confidence:.2f})"

# Gradio Interface
interface = gr.Interface(
    fn=predict,
    inputs=gr.Image(type="pil"),
    outputs="text",
    title="Fashion MNIST Classifier",
    description="Upload an image to classify it into one of the Fashion MNIST categories."
)

# Run the app
if __name__ == "__main__":
    interface.launch(share=True)


# In[ ]:




