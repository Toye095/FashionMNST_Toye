#!/usr/bin/env python
# coding: utf-8

# In[4]:


from dataset import Dataset
from model import CNNModel
import os

class TrainModel:
    def __init__(self):
        self.dataset = Dataset()  # Load dataset
        self.cnn = CNNModel()  # Initialize CNN model
        self.cnn.compile_model()  # Compile the model

    def train(self):
        # Train the CNN model
        history = self.cnn.get_model().fit(
            self.dataset.x_train, 
            self.dataset.y_train, 
            validation_split=0.2, 
            epochs=10, 
            batch_size=64
        )
        return history

    def save_model(self, path):
        # Ensure the directory exists before saving
        directory = os.path.dirname(path)
        if not os.path.exists(directory):
            os.makedirs(directory)

        # Save the model in Keras native format
        self.cnn.get_model().save(path)
        print(f"Model saved successfully at: {path}")

if __name__ == "__main__":
    trainer = TrainModel()  # Initialize the training process
    trainer.train()  # Train the model
    trainer.save_model("saved_model/fashion_mnist_cnn.keras")  # Save the model


# In[ ]:




