#!/usr/bin/env python
# coding: utf-8

# In[ ]:


from tensorflow.keras.models import Sequential            # for building CNN
from tensorflow.keras.layers import Conv2D, MaxPooling2D, Flatten, Dense, Dropout  # Import CNN layers

class CNNModel:
    def __init__(self):                                   # define constructor to initialize the CNN model
        self.model = Sequential()                        
        self.build_model()                               

    def build_model(self):                               # define method to build CNN model
        self.model.add(Conv2D(32, (3, 3), activation='relu', input_shape=(28, 28, 1)))  
        self.model.add(MaxPooling2D((2, 2)))            
        self.model.add(Conv2D(64, (3, 3), activation='relu')) 
        self.model.add(MaxPooling2D((2, 2)))            
        self.model.add(Conv2D(128, (3, 3), activation='relu'))  
        self.model.add(Flatten())                       
        self.model.add(Dense(128, activation='relu'))  
        self.model.add(Dropout(0.5))                    
        self.model.add(Dense(10, activation='softmax')) 

    def compile_model(self):                            # define method to compile CNN model
        self.model.compile(optimizer='adam', loss='categorical_crossentropy', metrics=['accuracy']) 
        
    def get_model(self):                                # define method to return the built model
        return self.model                               

