#!/usr/bin/env python
# coding: utf-8

# In[ ]:


from tensorflow.keras.datasets import fashion_mnist  # Import Fashion MNIST dataset
from tensorflow.keras.utils import to_categorical   #  to convert labels to one-hot encoding
import numpy as np                                   # for numerical manipulation

class Dataset:
    def __init__(self):                              # define constructor to initialize the dataset
        self.load_data()                             

    def load_data(self):                             # define method to load the Fashion MNIST dataset
        (self.x_train, self.y_train), (self.x_test, self.y_test) = fashion_mnist.load_data()  
        self.preprocess()                           

    def preprocess(self):                            # define method to preprocess the dataset
        self.x_train = self.x_train / 255.0         
        self.x_test = self.x_test / 255.0           
        self.x_train = np.expand_dims(self.x_train, -1)  
        self.x_test = np.expand_dims(self.x_test, -1)    
        self.y_train = to_categorical(self.y_train, 10)  
        self.y_test = to_categorical(self.y_test, 10)    

